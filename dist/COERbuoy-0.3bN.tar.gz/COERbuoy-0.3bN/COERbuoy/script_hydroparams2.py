import COERbuoy.Parameters;
import numpy as np;
import matplotlib.pyplot as plt;
import COERbuoy.utils as u;

u.set_settings("WECfolder","[data.COERsimple]");

z=0.0;
omega0=np.linspace(0.1,3.2,100);

i=0;
#fig=plt.figure(figsize=(20,7));
#plt.subplot(1,4,i);
fig, axes=plt.subplots(2,3);
#fig.set_figsize(20,7);
fig.set_figwidth(20)
fig.set_figheight(7)

param = COERbuoy.Parameters.parameters("[data.COERsimple]","Floater");
param.init_hydro(omega0); #select the frequencies

param2 = COERbuoy.Parameters.parameters("[data.COERsimple]","Floater_BEM");
param2.init_hydro(omega0); #select the frequencies

for z in [-2,0,2]:
    #plt.subplot(2,3,i);
    hyparams=param.hydro(z,1,1);#usage: params.hydro(submergence=0,mode1=1(heave,mode2=1(heave))
                                #returns: [buoyancy, excitation, rad. impedande, added mass at inf.]
    m0=np.imag(hyparams[3]);
    rad1=np.real(hyparams[2]);
    mad1=-np.imag(-hyparams[2]);
    exc1=np.real(hyparams[1]);


    hyparams2=param2.hydro(z,1,1);#usage: params.hydro(submergence=0,mode1=1(heave,mode2=1(heave))
                            #returns: [buoyancy, excitation, rad. impedande, added mass at inf.]
    m02=np.imag(hyparams2[3]);
    rad2=np.real(hyparams2[2]);
    mad2=-np.imag(-hyparams2[2]);
    exc2=np.real(hyparams2[1]);
    ka=omega0**2/9.81*4.5;

    #plt.figure();
    axes[0,i].plot(omega0,np.real(hyparams[1]/1e6),"r");
    axes[0,i].plot(omega0,np.imag(hyparams[1]/1e6),"r--");
    axes[0,i].plot(omega0,np.real(hyparams2[1]/1e6),"b");
    axes[0,i].plot(omega0,np.imag(hyparams2[1]/1e6),"b--");
    axes[0,i].set_ylim(-150000/1e6,500000/1e6);
    axes[0,i].set(ylabel='Excitation [MN/m]')
    if False:#(i-1)<1:
        print(i)
        plt.xlabel("omega [rad/s]");
        plt.ylabel("[F/m]");
        plt.legend(["real part (analytic)","imag part (analytic)","real part (Nemoh)","imag part (Nemoh)"]);
    #else:
        #plt.tick_params(labelleft=False)
        
    
    #plt.subplot(2,3,i+2);
    axes[0,i].set_title("z="+str(z))
    axes[1,i].plot(omega0,rad1/1e6,"r");
    axes[1,i].plot(omega0,mad1/1e6,"r--");
    axes[1,i].plot(omega0,rad2/1e6,"b");
    axes[1,i].plot(omega0,mad2/1e6,"b--");
    axes[1,i].set_ylim(0,125000/1e6);
    axes[1,i].set(ylabel='Radiation')
    #plt.title("Radiation coefficents")
    #plt.xlabel("omega [rad/s]");
    #plt.ylabel("[Fs/m]");
    i=i+1;
    #plt.legend(["real part (analytic)","imag part (analytic)","real part (Nemoh)","imag part (Nemoh)"]);
for ax in axes.flat:
    ax.set(xlabel='omega [rad/s]')

# Hide x labels and tick labels for top plots and y ticks for right plots.
for ax in axes.flat:
    ax.label_outer()

axes[0,2].legend(["Real BEM","Imag. BEM","Real analytic","Imag. analytic"])
axes[1,2].legend(["Resistance BEM [MNs/m]","Added Mass BEM [kt]","Resitance analytic [MN/s]","Added Mass analytic [kt]"])

fig.show();
fig.savefig("evaluation_parameters.pdf")