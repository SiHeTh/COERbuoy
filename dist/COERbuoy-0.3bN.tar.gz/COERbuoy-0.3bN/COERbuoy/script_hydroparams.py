#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 13 15:06:02 2022

@author: gast
"""
import COERbuoy.Parameters;
import numpy as np;
import matplotlib.pyplot as plt;
import COERbuoy.utils as u;

u.set_settings("WECfolder","[data.COERsimple]");

z=0.1;
omega0=np.linspace(0.1,3.2,100);

param = COERbuoy.Parameters.parameters("[data.COERsimple]","Floater");
param.init_hydro(omega0); #select the frequencies
hyparams=param.hydro(z,1,1);#usage: params.hydro(submergence=0,mode1=1(heave,mode2=1(heave))
                            #returns: [buoyancy, excitation, rad. impedande, added mass at inf.]
m0=np.imag(hyparams[3]);
rad1=np.real(hyparams[2]);
mad1=-np.imag(-hyparams[2]);
exc1=np.real(hyparams[1]);


param2 = COERbuoy.Parameters.parameters("[data.COERsimple]","Floater_BEM");
param2.init_hydro(omega0); #select the frequencies
hyparams2=param2.hydro(z,1,1);#usage: params.hydro(submergence=0,mode1=1(heave,mode2=1(heave))
                            #returns: [buoyancy, excitation, rad. impedande, added mass at inf.]
m02=np.imag(hyparams2[3]);
rad2=np.real(hyparams2[2]);
mad2=-np.imag(-hyparams2[2]);
exc2=np.real(hyparams2[1]);

plt.figure();
plt.plot(omega0,np.real(hyparams[1]),"r");
plt.plot(omega0,np.imag(hyparams[1]),"r--");
plt.plot(omega0,np.real(hyparams2[1]),"b");
plt.plot(omega0,np.imag(hyparams2[1]),"b--");
plt.title("Excitation coefficents")
plt.xlabel("omega [rad/s]");
plt.ylabel("[F/m]");
plt.legend(["real part (analytic)","imag part (analytic)","real part (Nemoh)","imag part (Nemoh)"]);
plt.show();

plt.figure();
plt.plot(omega0,rad1,"r");
plt.plot(omega0,mad1,"r--");
plt.plot(omega0,rad2,"b");
plt.plot(omega0,mad2,"b--");
plt.title("Radiation coefficents")
plt.xlabel("omega [rad/s]");
plt.ylabel("[Fs/m]");
plt.legend(["real part (analytic)","imag part (analytic)","real part (Nemoh)","imag part (Nemoh)"]);
plt.show();

plt.figure();
irf1=[];
irf2=[];
ts=np.linspace(0,0.25*np.pi/np.min(omega0),100);
#IRF Radiation
for t in ts:
    irf1.append(np.sum(rad1*np.exp(omega0*1j*t)));
    irf2.append(np.sum(rad2*np.exp(omega0*1j*t)));
plt.plot(ts,irf1,'r');
plt.plot(ts,irf2,'b');
plt.title("Radiation IRF")
plt.xlabel("time [s]");
plt.ylabel("[Fs/m]");
plt.legend(["analytic","Nemoh"]);