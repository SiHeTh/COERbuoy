#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 28 08:55:59 2020

@author: heiko
"""

import numpy as np;
import json;
from scipy.integrate import dblquad as int2d;
from scipy.special import jv as bessel;
from scipy.signal import hilbert as KramerKronig;
from scipy.optimize import fsolve;
#from scipy.fftpack import hilbert as KramerKronig;
from scipy.interpolate import interp1d;

pi=np.pi;
#wave=wavefield.wavefield(np.zeros(20),np.linspace(1,20),2)

class Cone:
  m = -1;
  q = -1;
  z1 = -1;
  z2 = 0;
  I = 0;
  g=9.81;
  zCoG = -1;
  depth=30;
  
  def __init__ (self, z1, r1, z2, r2, zCoG, xi, g, h):
      #Frequency parameters
      self.xi=xi;
      
      #geometric parameters
      self.m=(r1-r2)/(z1-z2);
      self.z1=z1;
      self.z2=z2;
      self.g=g;
      self.rho=1000;
      self.q=-r1+self.m*self.z1;
      self.omega=np.sqrt(self.xi*g);
      
      self.zCoG=zCoG;
      self.z0=0;
      self.x0=0;
      self.delta0=0;
      self.depth=h;
  
  def Ap(self, z, xi0, xis, eta, q):
      return np.exp(xis*(z-eta))/np.power(xis,4)*(3*xis*self.m**3*q*(xis**2*z**2-2*xis*z+2)+xis*self.m*q*(xis**2*(2*z**2+q**2)-4*xis*z+4)+xis**2*q**2*(xis*z-1)+self.m**4*(xis**3*z**3-3*xis**2*z**2+6*xis*z-6)+self.m**2*(xis**3*(z**3+3*z*q**2)-3*xis**2*(z**2+q**2)+6*xis*z-6));

  def Bp(self, z, xi0, xis, eta, q):
      return np.exp(xis*(z-eta))/np.power(xis,6)*(xis**4*q**4*(xis*z-1)+xis**2*self.m**2*q**2*(xis**3*(6*z**3+5*z*q**2)-xis**2*(18*z**2+5*q**2)+36*xis*z-36)+xis**3*self.m*q**3*(xis**2*(4*z**2+q**2)-8*xis*z+8)+5*xis*self.m**5*q*(xis**4*z**4-4*xis**3*z**3+12*xis**2*z**2-24*xis*z+24)+2*xis*self.m**3*q*(xis**4*(2*z**4+5*z**2*q**2)-2*xis**3*(4*z**3+5*z*q**2)+2*xis**2*(12*z**2+5*q**2)-48*xis+z+48)+self.m**4*(xis**5*(z**5+10*z**3*q**2)-5*xis**4*(z**4+6*z**2*q**2)+20*xis**3*(z**3+3*z*q**2)-60*xis**2*(z**2+q**2)+120*xis*z-120)+self.m**6*(xis**5*z**5-5*xis**4*z**4+20*xis**3*z**3-60*xis**2*z**2+120*xis*z-120))

  def As(self, z, xi0, xis, eta, q):
      return np.exp(xis*(z-eta))/np.power(xis,3)*(np.power(self.m,2)*(np.power(xis,2)*np.power(z,2)-2*xi0*z+2)+2*self.m*q*xis*(xis*z-1)+np.power(q,2)*np.power(xis,2));

  def Bs(self, z, xi0, xis, eta, q):
      return np.power(xi0,2)*np.exp(xis*(z-eta))/(8*np.power(xis,5))*(np.power(self.m,4)*(np.power(xis,4)*np.power(z,4)-4*np.power(xis,3)*np.power(z,3)+12*np.power(xis,2)*np.power(z,2)-24*xis*z+24)+4*np.power(self.m,3)*q*xis*(np.power(xis,3)*np.power(z,3)-3*np.power(xis,2)*np.power(z,2)+6*xis*z-6)+6*np.power(self.m,2)*np.power(q,2)*np.power(xis,2)*(np.power(xis,2)*np.power(z,2)-2*xis*z+2)+4*self.m*np.power(q,3)*np.power(xis,3)*(xis*z-1)+np.power(q,4)*np.power(xis,4))

  def Ah(self, z, xi0, xis, eta, q):
      return np.exp(xis*(z-eta))/np.power(xis,2)*(self.m*(xis*z-1)+xis*q)
      #return np.exp(xis*(z-eta))/np.power(xis,2)*(self.m*(xis*z-1)+xis*q)

  def Bh(self, z, xi0, xis, eta, q):
      return np.exp(xis*(z-eta))/np.power(xis,4)*(np.power(xis,3)*np.power(q,3)+3*xis*self.m*self.m*q*(np.power(xis,2)*np.power(z,2)-2*xis*z+2)+3*np.power(xis,2)*self.m*q*q*(xis*z-1)+np.power(self.m,3)*(np.power(xis,3)*np.power(z,3)-3*np.power(xis,2)*np.power(z,2)+6*xis*z-6))
      #return np.exp(xis*(z-eta))/np.power(xis,4)*(3*xis*self.m*self.m*q*(np.power(xis,2)*np.power(z,2)-2*xis*z+2)+np.power(self.m,3)*(np.power(xis,3)*np.power(z,3)-3*np.power(xis,2)*np.power(z,2)+6*xis*z-6))

  def Ch(self, z, xi0, xis, eta, q):
      return np.exp(xis*(z-eta))/np.power(xis,6)*(np.power(xis,5)*np.power(q,5)+5*np.power(xis,4)*self.m*np.power(q,4)*(xis*z-1)+10*np.power(xis,2)*self.m*self.m*self.m*q*q*(np.power(xis,3)*np.power(z,3)-3*xis*xis*z*z+6*xis*z-6)+10*np.power(xis,3)*self.m*self.m*np.power(q,3)*(xis*xis*z*z-2*xis*z+2)+5*xis*np.power(self.m,4)*q*(np.power(xis,4)*np.power(z,4)-4*np.power(xis,3)*np.power(z,3)+12*np.power(xis,2)*np.power(z,2)-24*xis*z+24)+np.power(self.m,5)*(np.power(xis,5)*np.power(z,5)-5*np.power(xis,4)*np.power(z,4)+20*np.power(xis,3)*np.power(z,3)-60*np.power(xis,2)*np.power(z,2)+120*xis*z-120))
      #return np.exp(xis*(z-eta))/np.power(xis,6)*(5*xis*np.power(self.m,4)*self.q*(np.power(xis,4)*np.power(z,4)-4*np.power(xis,3)*np.power(z,3)+12*np.power(xis,2)*np.power(z,2)-24*xis*z+24)+np.power(self.m,5)*(np.power(xis,5)*np.power(z,5)-5*np.power(xis,4)*np.power(z,4)+20*np.power(xis,3)*np.power(z,3)-60*np.power(xis,2)*np.power(z,2)+120*xis*z-120))

  def Calculate(self, z0, x0, delta0, eta):
      return self.Calculate_xi(z0, x0, delta0, eta, self.xi)
  def Calculate_xi(self, z0, x0, delta0, eta, xi0):
      #Acos=0.5*Acos
      #Asin=0.5*Asin
      z0=-z0;
      #eta=np.sum(Acos);
      
      #Calculate integration limits (dependent on buoy position)
      z1=self.z1+z0;
      z2=np.min([self.z2+z0,eta]);
      q=-self.q-(z0)*self.m;
      
      empty=[0,0,0]
      empty2=[np.array(xi0)*0,np.array(xi0)*0,np.array(xi0)*0]
      #If segment not in water, return zero
      if (z1>z2):
         return [empty,empty2];
      if (z1>eta):
         return [empty,empty2];
      
      
      #Using wheeler strechting to make linear wave theory less linear ;-)
      xis=np.array(xi0*self.depth/(eta+self.depth))#xi dived by water depth (h) and position over the surface eta.
      
      
      #buoyancy force (only heave)
      F_st_h=-self.g*self.rho*(2*pi*self.m*(((self.m*np.power(z2,3)/3+q*np.power(z2,2)/2))-(self.m*np.power(z1,3)/3+q*np.power(z1,2)/2)))
      F_st=[0,F_st_h,0]
      
      #dynamic Froude-Krylov force
      #surge
      c_dy_s=-self.g*self.rho*pi*xi0*(self.As(z2, xi0, xis, eta, q)-self.Bs(z2, xi0, xis, eta, q)-(self.As(z1, xi0, xis, eta, q)-self.Bs(z1, xi0, xis, eta, q)))
      
      #TODO: implement pitch
      c_dy_p=-self.g*self.rho*pi*xi0*(self.Ap(z2, xi0, xis, eta, q)-xi0**2/8*(self.Bp(z2, xi0, xis, eta, q))-(self.Ap(z1, xi0, xis, eta, q)-xi0**2/8*(self.Bp(z1, xi0, xis, eta, q))));
      
      #heave
      c_dy_h=(2*self.Ah(z2, xi0, xis, eta, q)-np.power(xi0,2)/2*self.Bh(z2, xi0, xis, eta, q)+np.power(xi0,4)/32*self.Ch(z2, xi0, xis, eta, q)-(2*self.Ah(z1, xi0, xis, eta, q)-np.power(xi0,2)/2*self.Bh(z1, xi0, xis, eta, q)+np.power(xi0,4)/32*self.Ch(z1, xi0, xis, eta, q)))
      c_dy_h=-pi*self.m*self.g*self.rho*c_dy_h;
      
      
      if (len(xi0)>1):
          #Avoid numerical errors
          i=np.argmax(np.diff(np.abs(c_dy_h))>0)
          if i>0:
              c_dy_h[i:]=0;
          i=np.argmax(c_dy_h<0)
          if i>0:
              c_dy_h[i:]=0;
              
      c_dy=[c_dy_s.copy(),c_dy_h.copy(),c_dy_p.copy()*0]
          
      
      
      ##For testing
      #c_dy[1]=np.arange(0,len(self.omega))  
      #m0[1]=10;
      #import pandas
      #file1=np.array(pandas.read_csv("ExcitationForce.tec",sep="\s+"));
      #file2=np.array(pandas.read_csv("DiffractionForce.tec",sep="\s+"));
      #self.omega=file1[:,0];
      #c_dy[1]=file1[:,3]*np.cos(file1[:,4])-file2[:,3]*np.cos(file2[:,4]);
      #m0=[1,0.5e5,1];
      
      return [F_st,c_dy];
  
  def Radius(self,z0):
      if(z0>=self.z1) and (z0<=self.z2):      
          r=-self.q+(z0)*self.m;
          return r;
      else:
          return 0;
      
  def max_Radius(self,z0):
      #get maximum radius for this section if the lowest part of this section is below z0
      if (z0>self.z2):
          return np.max([-self.q+(self.z1)*self.m,-self.q+(self.z2)*self.m]);
      if(z0>=self.z1) and (z0<=self.z2):      
          r=np.max([np.abs(-self.q+(z0)*self.m),-self.q+(self.z1)*self.m]);
          return r;
      else:
          return 0;
      
  def added_mass(self, scale, eta_z, eta_r, max_z, max_r):
      #cap z2 at water level
      z2=np.min([self.z2,eta_z]);
      z1=np.min([self.z1,eta_z]);
      r2=self.Radius(z2);
      r1=self.Radius(z1);
      dr=r2-r1;
      mean_z=0.5*abs(z2+z1)-eta_z;
      
      Vr=(r2**3-r1**3)*3.14*1000*2/3*0.5;
      
      a=1;#facing upwards
      if (dr<0):#facing upwards
          a=-0.5;
          
      
      b=0.9;
      
      return a*Vr#*b*mean_z;
      #if max_z>=eta_z:
      #    scale=scale*4.5#eta_r;
      #    d2=np.max([-1*(z2-eta_z),0])*scale;
      #    d1=np.max([-1*(z1-eta_z),0])*scale;
      #if max_z<eta_z:
      #    scale=scale*4.5#max_r;
      #    if self.z2<=max_z:
      #        d2=(max_z-z2)*scale;
      #        d1=(max_z-z1)*scale;
      #    if self.z1>=max_z:
      #        d2=(max_z-z2)*scale;
      #        d1=(max_z-z1)*scale;
      #        #d1=0
      #        #d2=0
              
      #A=0.5*(abs(d1)+abs(d2))*abs(self.Radius(z1)-self.Radius(z2));
      #V=abs(0.5*(abs(d1)+abs(d2))*3.14*self.Radius(z1)**2-0.5*(abs(d1)+abs(d2))*3.14*self.Radius(z2)**2);
      #print([z1,z2,d1,d2,self.Radius(z1),self.Radius(z2)])
      #print([eta_z,scale,A])
      #return V*1000;
 
  def Area (self, z0):
      #get the area at z0
          r=self.Radius(z0);#r = z0*self.m-q;
          return r*r*pi;
  
  def AreaSurge (self, z0):
          ru=self.Radius(z0);#r = z0*self.m-q;
          rb=self.Radius(self.z1);
          h=np.max([z0-self.z1,0]);
          return (ru+rb)*h;
      
  def Volume(self, z):
      z1l=np.min([self.z1,z])
      z2l=np.min([self.z2,z])
      z1l1=(z1l-self.q/self.m)
      z2l2=(z2l-self.q/self.m)
      r2=z2l2*self.m;
      r1=z1l1*self.m;
      return 1/3*pi*(r2*r2*z2l2-r1*r1*z1l1);


idname="test.csv";
class Floater:
    volume=0;
    mode=0;
    g=9.81;
    d=300;
    Cog=0;
    rho=1000;
    xi=np.array([]);
    
    def __init__ (self, xi, g, depth, CoG, *args):
        self.xi=xi;
        self.g=g;
        self.omega=np.sqrt(self.xi*self.g)
        self.elements=[];
        self.d=depth;
        self.CoG=CoG;
        self.file = open(idname+"_f.csv", "w")
        self.file.write("time,wave,buoyancy,FK,rad\r\n");
        if len(args)>0:
            with open(args[0]) as file:
                geo=json.load(file);
                for g in geo["geo"]:
                    if g["type"] == "cone":
                        self.addCone(g["coord"][0],g["coord"][1],g["coord"][2],g["coord"][3])
                    
                
        
    def addCone(self, z1, r1, z2, r2):
        self.elements.append(Cone(z1, r1, z2, r2,self.CoG,self.xi,self.g,self.d))
        self.volume=self.volume+self.elements[-1].Volume(z2);
    
    def set_mode(self, mode):
        self.mode=mode;
        
    def Calc_CoG(self):
        mi=0;
        ms=0;
        rge=np.linspace(np.min([e.z1 for e in self.elements]),np.max([e.z2 for e in self.elements]),10);

        for i in rge:
            ai=self.Area(i);
            mi=mi+ai*i;
            ms=ms+ai;
        return mi/ms;
        
    def get_parameters(self, z0, x0, delta0, eta):
        a=self.Calculate();
        a=[a[9],a[1],a[2],a[3]]
    def Calculate(self, z0, x0, delta0, eta):
        forces=np.array([[0,0,0],[self.omega*0,self.omega*0,self.omega*0]]);
        
        #Calc added mass
        m_tmp=self.added_mass(z0,eta);
        m0=np.array([m_tmp,m_tmp,m_tmp]);
        #print("m0: "+str(m0))
        #print(m_tmp)
        #Acos=0.5*Acos
        #Asin=0.5*Asin
        z0=-z0;
        #eta=np.sum(Acos);
        
        #his is used to calculate the parameters for visualisation, without considering the wave elevantion
        #if (Acos.size==0):
        #  Acos=np.ones(self.xi.size);
        #if (Asin.size==0):
        #  Asin=np.ones(self.xi.size);

        
        #Get buoyancy force and Froude-Krylov forces for each element
        for e in self.elements:
            forces = forces + e.Calculate(z0, x0, delta0, eta);
        if np.sum(np.abs(forces[0]))==0:#out of water
            en=[self.omega*0,self.omega*0,self.omega*0];
            return [forces[0],en,np.array([en,en,en]),[0,0,0]]
        
        #First assumption for the excitation force parameters is the the dyn. Froude-Krylov force, neglecting diffraction effects
        c_dy=forces[1];
        c_ex=c_dy.copy();
      
        #Initialization of parameters
        c_added_mass=[np.zeros(len(self.omega))+m0[0],np.zeros(len(self.omega))+m0[1],np.zeros(len(self.omega))+m0[2]];
        c_added_mass2=[np.zeros(len(self.omega)),np.zeros(len(self.omega)),np.zeros(len(self.omega))];
        c_diff=[np.zeros(len(self.omega)),np.zeros(len(self.omega)),np.zeros(len(self.omega))];
        c_rad=[np.zeros(len(self.omega)),np.zeros(len(self.omega)),np.zeros(len(self.omega))];
        F_dy=[np.zeros(len(self.omega)),np.zeros(len(self.omega)),np.zeros(len(self.omega))];
      
        #infinity depth approximation
        D=1 #finity depth: (1+(4*self.xi*self.depth*np.exp(-2*self.depth*self.xi))/(1-np.exp(-4*self.xi*self.depth)))*(1-np.exp(-2*self.xi*self.depth))/(1+np.exp(-2*self.xi*self.depth))
      
        #Using small body theory, only valid if body is small compared to the wave length.
        #Calculate frequency until tis approximation is accurate   
        
        #get max distance from watercrossare to wetted buoy shape
        #d_m=max([np.abs(e.z1) for e in self.elements])
        [z_min,z_max,z_r_max,r_max]=self.getGeoBox(z0+eta);
        
        #omega_limit=np.max([np.sqrt(self.g*2/(np.max([((z_max-z_min)**2+r_max**2)*0.5,0.001]))),1.5/r_max])
        omega_limit=np.sqrt(self.g*1/(np.max([r_max,0.001])))
        i_limit=np.argmax(self.omega>omega_limit)
              
        #Calculate low-pass to filter out results far away from omega_limit
        lp=self.omega*0+1;  
        
        if self.omega[-1]>omega_limit:
            for iii in range(i_limit,len(lp)):
                lp[iii]=np.max([1-(iii-i_limit)/(i_limit+1),0]);
        #print([omega_limit,lp,r_max])     
        scale=1;#np.linspace(1,0.75,len(self.omega));
        #print(lp)
        fdr=np.zeros(len(self.omega));#0*m1*self.omega2**2;
        fdr=[fdr,fdr,fdr];
        fdi=np.zeros(len(self.omega))#m1*self.omega2;
        fdi=[fdi,fdi,fdi];
        self.omega2=self.omega*scale;
        #Iterative process to calculate radiation, diffraction and added mass
        for i in range(1):
          #calculate all three degree of freedoms
          #print(c_dy)
          for ii in range(len(c_dy)):
              
              m1=m0[ii]*np.ones(len(self.omega));
              #m1[m1<0.5]=0.5;
              #m1=m0[ii]/0.5**m1;
              fdr[ii]=1*fdr[ii];#*m1*self.omega2**2;
              fdi[ii]=0.24*fdi[ii];#m1*self.omega2;
                      #2*3.14*(self.omega*self.omega*self.omega/self.g)/(4*pi*self.g**2*self.rho*1)
              c_1=2*3.14*(self.omega*self.omega*self.omega/self.g)/(4*pi*self.g**2*self.rho*D);
              def func(x):
                  #return self.omega*1j*(-am*self.omega*1j+2*3.14*(self.omega**3/9.81)/(4*20*3.14*9.81*1000)*(c_dy[ii]+fdr+x)**2)-fdr-x)
                  #return ((1/scale)**(1/3)*2*3.14*(self.omega*self.omega*self.omega2/self.g)/(4*pi*self.g**2*self.rho)*np.abs(-c_dy[ii]+fdr+fdi*1j)**2)-c_rad[ii];
                  #return (c_1*np.abs(-c_dy[ii]+fdr+fdi*1j)**2)-c_rad[ii];
                  return (c_1*((np.abs(c_dy[ii])+fdr[ii])**2+(x*self.omega)**2))-x;
                  #return c_1*(np.real(np.abs(c_dy[ii]+x)))**2*self.omega+x-np.array(c_ex[ii]);
              #fdi=0;
              #weg???
              #for (idx,e) in enumerate(c_dy[ii]):
              #    if abs(fdr[ii][idx])>abs(e)*0.3:
              #        fdr[ii][idx]=(fdr[ii][idx]/abs(fdr[ii][idx])*abs(e)*0.3*2+fdr[ii][idx])/3;
                  #if fdr[idx]>e*0.5:
                  #    fdr[idx]=fdr[idx]*0.5+(e-fdr[idx])*0.5;
                  #if fdr[idx]<-e*0.5:
                  #    fdr[idx]=fdr[idx]*0.5-(-e-fdr[idx])*0.5;
              
              c_ex[ii]=c_dy[ii]-(fdr[ii]+1j*fdi[ii]);
              
              D=1;
              #Caculate radiation coefficent with Haskind relation, Falnes book eq. (5.148)
              #c_rad[ii]=np.real(lp*0+c_1*c_ex[ii]*np.conjugate(c_ex[ii]))#-diff*0.1;
              c_rad[ii]=c_1*np.abs(c_ex[ii])**2;
              #fdr[ii]=-fsolve(func,fdr[ii]);
              
              test=np.imag(KramerKronig(c_rad[ii]));
              #Version1
              #test[test>0]=0;
              #fdr[ii]=0.5*(np.imag(KramerKronig(c_rad[ii]))-m1[ii])*self.omega**2;
              fdr[ii]=(test-m1)*self.omega**2;
              for iii in range(1,len(fdr[ii])):
                  if abs(fdr[ii][iii])>0.2*np.max(abs(c_dy[ii])) or fdr[ii][iii-1]<fdr[ii][iii]:
                      fdr[ii][iii]=fdr[ii][iii-1];
              fdr[ii][c_dy[ii]-fdr[ii]>0]=c_dy[ii][c_dy[ii]-fdr[ii]>0];
              fdr[ii][c_dy[ii]>0]=0;
              #fdr[ii]=fdr[ii]*0;
              #i_limit=[fdr[ii]>0] or [(-1*c_dy[ii]+fdr[ii])<0];
              #fdr[ii]=0.5*(fdr[ii]-abs(fdr[ii]))
              #fdr[ii][(-1*c_dy[ii]+fdr[ii])<0]=0;
              c_ex[ii]=c_dy[ii]-(fdr[ii]+1j*fdi[ii]);
              c_rad[ii]=c_1*np.abs(c_ex[ii])**2;#*lp;
              fdi[ii]=-1*c_rad[ii]*self.omega;
              c_ex[ii]=c_dy[ii]-(fdr[ii]+1j*fdi[ii]);
              #c_rad[ii]=fsolve(func,c_rad[ii],xtol=1e-3);#-self.omega*c_rad[ii];
              #fdi[ii]=-0.75*c_rad[ii]*self.omega;
              #fdi[ii]=test;
              c_ex[ii]=(c_dy[ii]-(fdr[ii]+1j*fdi[ii]));
              
              c_rad[ii]=c_1*np.abs(c_ex[ii])**2;#*lp;
        
              
              
              #Linear Max-Min
              c_added_mass[ii]=m1.copy()#-(np.max(c_added_mass[ii])-c_added_mass[ii][-1])/len(c_added_mass[ii])*np.arange(0,len(c_added_mass[ii]),1)+np.max(c_added_mass[ii]);
              #c_added_mass[ii]=-(2*m0[ii]-m0[ii])/len(c_added_mass[ii])*np.arange(0,len(c_added_mass[ii]),1)+2*m0[ii];
              
        c_rad_cmplx=np.real(c_rad)+1j*np.real(c_added_mass);
        #print("results")
        #print([forces[0],c_ex,[c_rad_cmplx,c_rad_cmplx,c_rad_cmplx],m0])
        return [forces[0],-1*np.array(c_ex.tolist()),[c_rad_cmplx,c_rad_cmplx,c_rad_cmplx],m0];
    
    #def get_forces(self, t, wave, z0, x0, delta0, v, a):
    def get_forces_old(self, t, wave, p, v, a):
        #Acos=0.5*Acos;
        #Asin=0.5*Asin;
        [x0,z0,delta0]=p;
        #a=a[1];
        Awave=wave.get(t,x0);
        #Awave[0]=Awave[0]*2;
        #Awave[1]=Awave[1]*2;
        eta=np.sum(Awave[0].real);
        res=self.Calculate(z0, x0, delta0, eta);
        ret=[0,0,0];
        exc1 = np.array(res[1]);#Exitation force
        rad = np.real(res[2]);#added mass over omega
        am1 = np.array(res[3]);#added mass @ inf

        
        def m(a,b):
            return a.real*b.real+a.imag*b.imag;
        
        if (np.sum(np.abs(res[1][1]))>0):
            #print(v)
            #print(rad[1])
            r1=-2/np.pi*rad[1]/(exc1[1]*1);#imag is sometimes zero...
            r1[np.isnan(r1)]=0;#...leading to Nan, set zero again
            wave.add_diracWave(r1*v[1],t,True);
            #wave.add_diracWave(-2/np.pi*(res[2][1])/((res[1][1]))*(a-Awave[3])/self.omega,t,False);
        
        for i in range(len(res[0])):
            #Fb=res[0][1]-self.Volume(0)*self.rho*self.g;
            #FK=np.sum(np.real(res[1][i])*Awave[0]+np.imag(res[1][i])*Awave[1])
            Fexc=np.sum(m(exc1[i],Awave[0])).real;
            ret[i]=res[0][i]+0*Fexc;#-0*res[2][i]*Speed+0*res[3][i]*Acceleration);
            #FK=np.sum(np.real(res[1][1])*Awave[0]+np.imag(res[1][1])*Awave[1])#for force output file
        Frad=np.real(np.sum(wave.get_rad(t,x0)*exc1[1]));
        #Frad=[ np.real(np.sum(wave.get_rad(t,x0)*(exc1[1]  ))),0];
        ret[1]=np.array(ret[1])+np.array([0,Frad,0]);
        
        
        #self.file.write(str(t)+","+str(eta)+","+str(Fb)+","+str(FK)+","+str(Frad)+"\r\n");
        return [ret,res[3]];
    def get_forces(self, t, wave, p, v, a):
        z0=p[1];
        x0=p[0];
        delta0=p[2];
        
        Awave=wave.get(t,x0);
        eta=np.sum(np.real(Awave[0]));
        
        res=self.Calculate(z0, x0, 0*delta0, eta);#Calculate coefficents
      
        ret=[0,0,0];#return array
        def m(a,b):
            return a.real*b.real+a.imag*b.imag;

        exc1 = np.array(res[1]);#Exitation force
        am_omega = np.real(res[2]);#damping over omega
        am1 = np.array(res[3]);#added mass @ inf
        #print([exc1.shape,am_omega.shape])
      
        #am_omom=np.array(am_omega)/np.array([exc1,exc1,exc1]);#np.matmul(am_omega,vv)+np.diag((am_omega-self.rad_old)/np.max([t-self.t_old,1e-5]));

        if (np.sum(np.abs(exc1))>0):
            #r1=1*am_omom[1][1]*(v[1])+am_omom[0][1]*(v[0]);
            r2=0#1*am_omom[0][0]*(v[0])+am_omom[1][0]*(v[1]);
            #print(r1)
            r1=am_omega[1][1].real/exc1[1].real+am_omega[1][1].imag/exc1[1].imag;#imag is sometimes zero...
            r1[np.isnan(r1)]=0;#...leading to Nan, set zero again
            wave.add_diracWave(-2/np.pi*r1,t,True);
            wave.add_diracWave2(-2/np.pi*r2,t,True);
        #Calculate hydro forces for each DOF
        for i in range(len(ret)):
            FK=np.sum(m(exc1[i],Awave[0])).real;
            ret[i]=res[0][i]+FK;#buoyance + FK force
            if i==1 and v[i]>0:#added mass only implemented for heave
                dP=(am1[i]-self.added_mass(z0+v[i]/abs(v[i])*0.01,eta))/0.01*v[i];
                ret[i]=ret[i]-dP;
                #print(str(t)+": "+str(dP)+", "+str(p[1]))
        Frad=[np.real(np.sum(wave.get_rad2(t,x0)*(exc1[0]))),np.real(np.sum(m(wave.get_rad(t,x0),exc1[1]))),0];#radiation force
        ret=np.array(ret)+np.array(Frad);
        return [np.real(ret),[am1[0],am1[1],am1[2]]];#hydro force, added mass @ inf

        
    def get_force_lin(self, t, wave, z0, x0, delta0, v, a):
        ret=self.get_forces(t,wave,0,0,0,v,a);
        ret[1]=ret[1]-self.Area(0)*1000*z0*9.81;
        return ret;        
        
    def Area(self, z0):
        area=0;
        for e in self.elements:
            area = e.Area(z0);
            if area >0:
                return area;
        return area;
    
    def AreaProjectedHeave(self, z0):
        area=0;
        res=self.getGeoBox();
        zrmax=res[2];
        rmax=res[3];
        
        if (z0>zrmax):
            return rmax**2*np.pi;
        for e in self.elements:
            area = area + e.Area(z0);
        return area;
        
    def AreaProjectedSurge(self, z0):
        area=0;
        for e in self.elements:
            area = area + e.AreaSurge(z0);
        return area;
    
    def getGeoBox(self,z0=np.NaN):
        #gets the max and min heave position (z_min and z_max) and the maximal radius r_max and its vertical position z_r_max
        z_min=np.NaN;
        z_max=np.NaN;
        r_max=0;
        z_r_max=0;
            
        for e in self.elements:
            z1=e.z1;
            z2=e.z2;
            if (not np.isnan(z0)):
                z1=np.min([z1,z0]);
                z2=np.min([z2,z0]);
                
            if np.isnan(z_min):
                z_min=z2;
                z_max=z1;
                
            if  z_min>z1:
                z_min=z1;
            if  z_max<z2:
                z_max=z2;
            if e.Radius(z1)>r_max:
                r_max=e.Radius(z1);
                z_r_max=z1;
            if e.Radius(z2)>r_max:
                r_max=e.Radius(z2);
                z_r_max=z2;
        return (z_min,z_max,z_r_max,r_max)
        
    
    
    def added_mass(self, z0, eta):
        z0=-z0;
        [z_min,z_max,z_r_max,r_max]=self.getGeoBox(z0+eta);
        h=(z_r_max-z_min);
        if h==0:
            return 0;
        a=r_max;
        pol=[1.22426941e-05,-4.11227691e-04,5.44460874e-03,-3.57578423e-02,1.20574494e-01,4.36864944e-01,-3.07493344e-02];
        return np.real(np.polyval(pol,a/h)*self.Volume(z_r_max)*self.rho);
    
    def max_radius(self,z0):
        #get maximal radius for the body below z0
        return np.max([e.max_Radius(z0) for e in self.elements]);
    
    
    def radius(self,z0):
        #get radius for the body at z0
        return np.max([e.Radius(z0) for e in self.elements]);
    
    def Volume(self, z0):
        vol=0;
        for e in self.elements:
            vol = vol + e.Volume(z0);
        return vol;
    
    def clear(self):
        self.file.close();
        self.elements.clear();
