#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys;
sys.exit(42);
