#Cone

import numpy as np;
import socket
import time
import json
import pdb
from ddeint import ddeint;

interface=True#False;
rho=1000;
pi=np.pi;
g=9.81;
dt=0.1;
h=60;
# Model
import pandas;

# FFT
a=np.array(pandas.read_csv("TestFull.csv", header=None))
t=a[:,0];
y=a[:,1];
y=2.5*np.sin(6/4.5*t);
Y=(np.fft.fft(y))/y.size;

omega=np.array(range(0,int(Y.size/2)-1))+1;
A=np.abs(Y);
alpha=np.angle(Y);
A=2*A[1:int(Y.size/2)]
phase=alpha[1:int(Y.size/2)]
omega=omega/t[-1]*(2*pi);

oi1 = np.argmax(omega>0.24);
oi2 = np.argmax(omega>2.5)
omega = omega[oi1:oi2];
print(omega)
phase = phase[oi1:oi2];
A = A[oi1:oi2];
import matplotlib.pyplot as pyplt;

#deep wave approximation
xi=omega*omega/g;


#Test oonly
#phase=phase*0
#A=A*0
#A[0]=1


from scipy.integrate import dblquad as int2d;
from scipy.special import jv as bessel
import Floater as fl;

rad=np.array(pandas.read_csv("IRF2.tec",sep="\s+"))[:,0::2];
#TODO: inerpolate data to dt
lastt=0;
u=np.zeros(rad.size);
lastt=0;
t1=0;
#i=rad.size;
from scipy.integrate import solve_ivp, RK45
#from ddeint import ddeint

CoG=-1;
#I=2*np.abs(3/10*mass*r1*r1-3/10*mass*r2*r2);
I=1000;
m0s=0;
i0=0;

buoy=fl.Floater(xi,9.81,300,0,'floater.txt');
t[-1]=50;
steps=np.array(range(0,int(1/dt*t[-1])))*dt;

mass=buoy.Volume(0)*1000*9.81/4;

Force_controller=0;
ttemp=t;

#def dynamics(x,t):#while t1<t[-1]
#  x=X(t)
def dynamics(t,x):#while t1<t[-1]
  
  #tune draft
  offset=0#-4#-1.9;
  
  #used static damping
  damping=100000
  #added mass floater
  m0=0.98e5;
  #Total mass of the system
  m=buoy.Volume(0)*1000*9.81/4;
  #Percentage mass floater
  mb=1;
  #Percentage mass slider
  ms=0.35;
  #floater-slider stiffnes
  c_fs=-buoy.Area(0)*1000*9.81+100000;
  #radiation damping
  drad=10000;
  #drag coefficent
  cD=0.5;
  
  
  #Calculate surface elevation eta
  F_FKS = buoy.Calculate(-x[0]*0+offset,x[2],x[4],A*np.sin(omega*t+phase),A*np.cos(omega*t+phase),0,1,0)
  #print(np.sum(A*np.cos(omega*t+phase)))
  F_FKS = F_FKS*rho*g;
  
  #Radiation
  #Instead of using a DDE solver...
  dynamics.u[int(t/dt)+1]=x[1];

  F_rad=0#-0*np.sum(np.convolve(rad[:,1],dynamics.u[np.max([int(t/dt)-int(rad[-1,0]/dt),0]):int(t/dt)+1]));
  #F_rad=np.sum(np.convolve(rad[:,1],x(rad[:,0])[1]));
  #F_rad=0;
  #for idx,rad1 in enumerate(rad[:,1]):
  #    F_rad=F_rad+rad1*x(t-rad[idx,0])[1];
 # F_rad=-np.max([(8-abs(x[0]))/8,0])*drad*x[1];
  F_rad=-100*x[1];
  ref_speed=0;
  if interface:
      tseq=np.linspace(t-20,t+20,80);
      tseq2=np.linspace(-20,20,80);
      tseq2=(tseq-tseq[int(tseq.size/2)]);
      
      msg={"time":tseq.tolist(),
           "wave":(np.sum(A*np.cos(omega*tseq.reshape(tseq.size,1)+phase),1)).tolist(),
           "speed":x[1]}
      #tseq2=(tseq-tseq[int(tseq.size/2)]);
      #msg={"time":tseq2.tolist(),"wave":(1*np.cos(0.75*tseq2+1.5*pi/2)).tolist()}
      
      #print((np.sum(A*np.cos(omega*tseq.reshape(tseq.size,1)+phase),1))[int(tseq.size/2)])
      socket.send((json.dumps(msg)).encode());
      data=json.loads(socket.recv(BUFFER_SIZE));
      #idx=data["time"].index(0);
      i=data["time"].index(0);
      #i=int(len(data["time"])/2)
      Force_controller=data["force"][i]
      #print([ref_speed[0]-x[1]])
      if (t-dynamics.lasttt>5):
          dynamics.lasttt=t;
          #pyplt.figure()
          print(str(x[8])+" Ws, Position "+str(x[0])+" m.")
          #pyplt.plot(ttemp[0:400],y[0:400])
          #pyplt.plot(msg["time"],msg["wave"])
          #pyplt.plot(data["time"],data["valve"])
          #pyplt.plot(data["time"],data["speed"])
  
     #     F_FKS2 = buoy.Calculate(0,x[2],x[4],A*np.sin(omega*t+phase),A*np.cos(omega*t+phase),0,1,0)[0]*rho*g;
     #     print(F_FKS2)
          #pyplt.stem([0],[F_FKS2])
          #pyplt.stem([-dt*2,-dt,0],dynamics.u[-3:])
      #pyplt.plot(data["time"],np.array(data["force"])/100000)
      F_PTO=-Force_controller[0]#+(ref_speed[0]-x[1])*150000;#(x[1]-x[7])*damping;
      #print(F_PTO)
  else:
      F_PTO=-(x[1]-x[7])*damping;
  
#  for z0 in range(-12,12):
#      F_FKS = buoy.Calculate(-z0,x[2],x[4],A*1,t)
#      pyplt.stem([z0],[F_FKS[0]])
  #Wave spring:
  #WS=-100*np.arctan((x[0]-x[6])/8)-mass/2*9.81;
  WS=c_fs*(x[0])
  WS2=-mass*(1-mb)*g;
  Fdraft=-0.5*rho*x[1]*np.abs(x[1])*cD*buoy.Area(-x[0])
  F_mooring=-x[6]*400000-4000*x[7]#-x[6]*10;
  #F_PTO=np.max([np.min([F_PTO,-5000]),5000]);
  #print(F_FKS[0],WS,x[0],x[6])
  dx=np.zeros(10);
  dx[1]=(F_FKS[0]+np.sum(F_FKS[1])+F_rad+WS+F_PTO)/(mass*mb+m0)
  dx[0]=x[1];
  dx[3]=0;
  dx[2]=x[3];
  dx[5]=0;
  dx[4]=x[5];
  dx[7]=0#(-F_PTO+F_mooring-WS-WS2-mass*(1-mb)*g)/(mass*(ms))
  dx[6]=x[7];
  dx[8]=-F_PTO*(x[1]-x[7]);
  dx[9]=F_PTO/6000;
  #print(-F_PTO*(x[1]-x[7]))
  return dx;


dynamics.lasttt=0;
dynamics.u=np.zeros(int(1/dt*t[-1])+2);

u=np.array(rad[:,1])*0;

if interface:
    TCP_IP = 'localhost'
    TCP_PORT = 5050
    BUFFER_SIZE = 1024*8;

    socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    socket.connect((TCP_IP, TCP_PORT))
    socket.send((3).to_bytes(2,byteorder="little"));
    data = socket.recv(BUFFER_SIZE)
    len_data=int.from_bytes(data,byteorder="little");
    print ("received data packet size:", len_data)

sol = solve_ivp(dynamics,[0,t[-1]],[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],t_eval=steps.tolist(),rtol=1e-3,atol=1e-5)#state vecor[z, dz, x, dx, delta, ddelta, slidex, dslidex]
#gt=lambda t: np.array([0, 0, 0, 0, 0, 0, 0, 0, 0])
#sol = ddeint(dynamics, gt, steps)


#vyt=[];
#vyy=[];
#ts=[];
#ys=[];

#while vy.t<t[-1]-20:
#    data={"time":t[vy.t:20/dt],
#    "wave":A*np.cos(omega*t[vy.t:20/dt]+phase)}
#    socket.send(data);
#    data=socket.recv(BUFFER_SIZE);
#    Force_controller=data["force"][5];
#    [vyt, vyy]=inte.step();
#    ts=[ts,vyt];
#    ys=[ys,vyy];
#gt=lambda t: np.array([0, 0, 0, 0, 0, 0, 0, 0])
#sol = ddeint(dynamics, gt, steps)

pyplt.figure()
pandas.DataFrame(np.array([sol.t[:],sol.y[0,:],sol.y[1,:],sol.y[9,:],sol.y[8,:]]).transpose()).to_csv("output.txt",index=False,header=False)
#pandas.DataFrame(np.array([sol.t[:],sol.y[0,:],sol.y[8,:]]).transpose()).to_csv('output.txt',index=False,header=False)
pyplt.plot(t[:int(t[-1]*10)],y[:int(t[-1]*10)])
pyplt.plot(sol.t,sol.y[0,:])
pyplt.plot(sol.t,sol.y[1,:])
pyplt.plot(sol.t[:-1],(sol.y[9,:-1]-sol.y[9,1:])/20)
#pyplt.plot(sol.t,sol.y[7,:])
print("Watt:")
print(sol.y[8,-1]/t[-1])