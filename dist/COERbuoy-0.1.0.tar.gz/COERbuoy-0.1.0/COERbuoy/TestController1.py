#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Simple test Controller

@author: Simon H. Thomas, COER laboratory, Maynooth University
"""
import numpy as np;
from scipy.interpolate import interp1d;
import connection;

host=True;           
    
conn_model=connection.connection();
    
if host:
    conn_model.openH();
else:
    conn_model.openC();
    
while buf_l:=conn_model.get_control():

  buf_time=buf_l["time"]
  y=buf_l["wave"];
  
  #filter signal to avoid jumps
  fy=interp1d(buf_time[:1]+buf_time[20:],y[-1:]+y[20:]);
  y=fy(buf_time);
  
  Y=(np.fft.fft(y))/y.size;
  Y=Y[1:int(Y.size/2)];
  
  z=buf_l["stroke_speed"];
  #filter signal to avoid jumps
  fz=interp1d(buf_time[:1]+buf_time[20:],z[-1:]+z[20:]);
  z=fz(buf_time);
  
  Z=(np.fft.fft(y))/z.size;
  Z=Z[1:int(Z.size/2)];
  
  #Get most significant frequency index
  idx=np.argmax(Y);
  
  #Calculate phase offset
  e=(np.angle(Z[idx])-np.angle(Y[idx]));
  
  #Calculate PTO Force based on phase offset
  F_pto=(e*400000/(3.14)+200000)*z[-1];
  
  #Set control message    
  answer={
          "time":np.linspace(buf_time[-1],buf_time[-1]+1,9),
          "pto":np.array([np.real(F_pto*-1)]*9),
          "break":np.zeros(9),
          "test":np.zeros(9),
          }
  #Send control message to model
  conn_model.set_control(answer["time"],answer["pto"],answer["break"],answer["test"]);
conn_model.close();
