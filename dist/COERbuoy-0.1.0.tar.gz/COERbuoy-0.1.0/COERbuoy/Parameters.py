#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Oct 17 13:34:05 2020

@author: heiko
"""

import numpy as np;
import pandas;
import dynamics_coerbuoy as dynamics#coer;
#import dynamics_sphere as dynamics
def run():
    omega=np.round(np.linspace(0.1,dynamics.omega_cut_off,10),10);#select frequency used
    xi=omega*omega/9.81;
    
    #Initialize WEC
    wec=dynamics.WEC();
    wec.load_buoy(xi,300,0);
    wec.load_param();
    
    limit=7;#heave limit inbetween which to calculate parameters
    delta=0.1;
    zs=np.linspace(-limit,limit,limit*8+1);#submergence levels at which to evaluate
    
    area=np.zeros(zs.size);
    vol=np.zeros(zs.size);
    Fstat=np.zeros(zs.size);
    Fdyn=np.zeros([zs.size,xi.size]);
    Frad=np.zeros([zs.size,xi.size]);
    Amass=np.zeros([zs.size,xi.size]);
    Fdiff=np.zeros([zs.size,xi.size]);
    floater_slider_spring=np.zeros(zs.size);
    
    #Madd-Damper-Spring parameters
    mdc=np.array([0,0,0]);
    
    mode=1;#0-surge, 1-heave, 2-pitch
    
    wec.buoy.Calculate(0,0,0,0);
    
    for idx,z in enumerate(zs):#calculate parameters for each submergence level
        area[idx]=wec.buoy.Area(z);
        vol[idx]=wec.buoy.Volume(z);
        results=wec.buoy.Calculate(z,0,0,0)
        results2=wec.buoy.Calculate(z-delta,0,0,0);
        Fstat[idx]=(results[0][mode]-results2[0][mode])*1/delta;
        Fdyn[idx]=np.real(results[1][mode]);
        Frad[idx]=results[2][mode];
        Amass[idx]=results[3][mode];
        Fdiff[idx]=np.imag(results[1][mode]);
        floater_slider_spring[idx]=(wec.Calc_fs_spring(z,0)-wec.Calc_fs_spring(z-delta,0))*1/delta;
        
        #Get linear parameter only at zero position
        if z==0:
            mdc[1]=Frad[idx][0];
            mdc[2]=-Fstat[idx]#-floater_slider_spring[idx]);
    
    print("calculation finished")
    omega2=[];
    
    #Write data
    folder="param/";
    for o in omega:
        omega2.append("&omega;="+str(o.round(2))+" rad/m");
    pandas.DataFrame(np.vstack((zs,area,vol)).transpose(),columns=["z-offset","cross-sec.area","volume"]).round(2).to_csv(folder+"HydroParam1.csv",index=False)
    pandas.DataFrame(np.vstack((zs,Fstat,floater_slider_spring,Fstat+floater_slider_spring)).transpose(),columns=["z-offset","c_hydrostatic","c_spring","resulting"]).round(2).to_csv(folder+"Stiffness.csv",index=False)
    pandas.DataFrame(np.vstack((zs,Fdyn.round(0).transpose())).transpose(),columns=["Froude-Krylov force"]+omega2).to_csv(folder+"fk_force.csv",index=False)
    pandas.DataFrame(np.vstack((zs,Frad.round(0).transpose())).transpose(),columns=["Radiation force"]+omega2).to_csv(folder+"radiation_force.csv",index=False)
    pandas.DataFrame(np.vstack((zs,Amass.round(0).transpose())).transpose(),columns=["Added mass"]+omega2).to_csv(folder+"added_mass.csv",index=False)
    pandas.DataFrame(np.vstack((zs,Fdiff.round(0).transpose())).transpose(),columns=["diffraction force"]+omega2).to_csv(folder+"diff_force.csv",index=False)

    mdc=mdc+wec.pto_mdc();#Get lienarized data from WEC
    
    #... now the linearized eigenfrequencys can be calculated
    deigfreq=2*np.pi/np.sqrt(mdc[2]/mdc[0]-(0.5*mdc[1]/mdc[0])**2)
    eigfreq=2*np.pi/np.sqrt(mdc[2]/mdc[0])
    pandas.DataFrame(np.vstack((mdc[0],mdc[1],mdc[2],eigfreq,deigfreq,wec.buoy.Calc_CoG())).transpose(),columns=["mass","damping","stiffness","eigenperiod","damped eigenperiod","Center of Gravity"]).round(2).to_csv("param/info.csv",index=False)

    #clearning up
    wec.release();

if __name__ == "__main__":
    run();    