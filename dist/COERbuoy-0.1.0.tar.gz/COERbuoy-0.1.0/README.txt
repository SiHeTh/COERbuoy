
COERbuoy platform

A realistic Wave Energy Converter model to evaluate controller
Website: coerbuoy.maynoothuniversity.ie
