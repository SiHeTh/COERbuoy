#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug  7 23:16:53 2020
Moment-based control with TCP interface; no bugfixing, testing only

@author: Simon
"""
import numpy as np;
import pandas;
from scipy.interpolate import interp1d;
from cvxopt import matrix, solvers;
import matplotlib.pyplot as pyplt;
import socket;
import json;
import sys;
import Floater as fl;
import connection;

#set time step

#set frequencies
omega0=np.array([0.2,0.4,0.6,0.8,1,1.2,1.4,1.6,1.8,2,2.2,2.4,2.6,2.8,3]);

#number of frequencies (k)
k=omega0.size;
host=True;

# Model

rho=1000;
pi=np.pi;
g=9.81;
h=60;

def planck_window(N, epsilon):
    w0=[0];
    n=np.array(range(1,int(np.around(epsilon*N))))
    w1=1/(1+np.exp(epsilon*N/n-epsilon*N/(epsilon*N-n)));

    w2=np.ones([1,int(np.around(N/2-epsilon*N))]).flatten()

    w=np.concatenate([w0,w1,w2]);
    w=np.concatenate([w,np.flip(w,axis=0)]);
    return w;

rad=np.array(pandas.read_csv("RadiationCoefficients.tec", header=2, sep='\s+'))[:,0:3]
#exc=np.array(pandas.read_csv("IRF2.tec", header=None, sep='\s+'))[:,0:2]

#Setting transformation matrix Se
Se2=np.array([]);
Se=np.array([]);
S=np.zeros([omega0.size*2,omega0.size*2]);

for idx, w in enumerate(omega0):
    S[idx*2+1,idx*2]=-w;
    S[idx*2,idx*2+1]=w;


#ts=np.linspace(0,int(2*pi/np.min(omega0)),2*(k*2+2));
ts=np.arange(0,2*pi/np.min(omega0),1/(2*np.max(omega0)));


for t in ts:#np.linspace(0,int(2*pi/np.min(omega0)),2*(k*2+2)*5):
    a=np.array([])
    for w in omega0:
        a=np.append(a,[np.cos(w*t),-np.sin(w*t)]);
    if Se.size == 0:
        Se=a;
    else:
        Se=np.vstack([Se,a])

tSe2=np.linspace(0,int(2*pi/np.min(omega0)),2*(k*2+2)*20)
for t in tSe2:
    a=np.array([])
    for w in omega0:
        a=np.append(a,[np.cos(w*t),-np.sin(w*t)]);
    if Se2.size == 0:
        Se2=a;
    else:
        Se2=np.vstack([Se2,a])
tSe2=tSe2-tSe2[int(tSe2.size/2)];

#deep wave approximation
xi=omega0*omega0/g;


filename="floater.txt";
buoy=fl.Floater(xi,9.81,300,0,filename);

with open(filename) as file:
    data=json.load(file);
    #used static damping
    c_minus =data.get("negative_spring",100000);
    d_m =data.get("machinery_damping",0);
    #Drag coefficent
    cD=data.get("drag",0.5);
    #Percentage mass floater
    m_mass=data.get("mass_percent_floater",0.25)+data.get("mass_percent_slider",0.25)
    added_m=data.get("added_mass",0.95e5);
    #generator efficency
    losses_coil=1/data.get("eff_generator",0.8);
    fr_s=data.get("friction_static",0);
    #static friction
    fr_d=data.get("friction_dynamic",0);
    #machinery damping
            

ts=ts-int(ts[-1]/2);
dt=ts[1]-ts[0];
#parameters
i=0;
move=0.5;
m=buoy.Volume(0)*1000*m_mass;#339120/4;
d=d_m+0.5*buoy.Area(0)*cD#buoy.Calculate(0,0,0,1,1,0,0,1)[3]*9.81;
c=buoy.Area(0)*1000*9.81;
c=c-c_minus;
print(c)

#Create Interpolation function
#fe=interp1d(exc[:,0],exc[:,1])
fm=interp1d(rad[:,0],rad[:,2])
fr=interp1d(rad[:,0],rad[:,1])

#radf=buoy.Calculate(0,0,0,np.array([]),np.array([]),0,1,np.ones(omega0.size))[4]*1000*9.81;
#rad2=np.abs(np.fft.ifft(radf))[:omega0.size(0)]

#cexc=fe(ts[:(np.argmax(ts>exc[-1,0]))-1])
#Interpolate radiation terms
m0=added_m;#rad[-1,2];
rad1=fr(omega0)#*9.81;
mad1=-omega0*(fm(omega0)-rad[-1,2])

#Fill Raditaion matrix
R=np.zeros([rad1.size*2,rad1.size*2]);
for idx, (m0, r0) in enumerate(zip(mad1,rad1)):
    R[idx*2,idx*2]=r0;
    R[idx*2+1,idx*2]=m0;
    R[idx*2,idx*2+1]=-m0;
    R[idx*2+1,idx*2+1]=r0;

#State Space matrices
A=np.array([[0, 1],[-c/(m+m0), -d/(m+m0)]]);
B=np.array([[0],[1/(m+m0)]]);
C=np.array([0, 1]);

#Cacluate Tr matrix  
I=np.eye(k*2);
T1=np.kron(I,C);
T2=np.kron(S,np.eye(A[1,:].size))+np.kron(np.eye(S[:,1].size),A);
T3=np.kron(I,-B);
Ts=np.matmul(np.matmul(T1,np.linalg.inv(T2)),T3);
Tr=np.matmul(np.linalg.inv(np.eye(Ts[:,1].size)+np.matmul(Ts,R.transpose())),Ts).transpose()
#Tr2=(Tr+Tr.transpose())/2;  
Tr2=Tr*np.eye(Tr[:,1].size)#numerically better

nabla=np.vstack([Se, -Se]).transpose()
X_Max=1.5;

#Set constraint
c1=np.matmul(np.matmul(-Tr,np.linalg.inv(S)),nabla);
#print(c1)
conn_model=connection.connection();
    
if host:
    conn_model.openH();
else:
    conn_model.openC();


def Calc_fe(wave,z):
    fe=np.zeros([Se.shape[0]]);
    z=np.matmul(Se,z);
        
    a12=np.linalg.lstsq(Se,wave)[0];
    ab=np.sqrt(a12[::2]**2+a12[1::2]**2);
    ##phase was always -, now works better with positive ?????
    #phase=np.arctan2(a12[1::2],a12[::2]);
    phase=-np.arctan2(a12[1::2],a12[::2]);
    for idx, z1 in enumerate(z):        
        fe[idx]=np.sum(buoy.Calculate(z1,0,0,ab*np.sin(omega0*dt*idx-phase),ab*np.cos(omega0*dt*idx-phase),0,1,0)[1]);
        #fe[idx]=f[0]*0+np.sum(f[1]);
        #fe[idx]=np.sum(ab*np.cos(omega0*dt*idx-phase));
    return np.linalg.lstsq(Se,fe)[0]*rho*g;

tnow=0;
ts=ts-ts[int(ts.size/2)];#to get an 0
while True:
  buf_l=conn_model.get_control();
  if not buf_l: break
  buf_time=np.array(buf_l["time"])
  buf_time=buf_time-(buf_time[0]+buf_time[-1])/2;
  window_time=ts;
  
  #Set the incoming wave into the right format
  f=interp1d(buf_time.tolist(),buf_l["wave"]);
  
  #print(window_time) 
  #Windowing only for receeding horizon
  win = planck_window(window_time.size,0.2)[0:window_time.size]
  windowed_sample=f(window_time)*win;
  #print(windowed_sample[int(5)])
  Lw , tmp1,tmp2,tmp3=np.linalg.lstsq(Se,windowed_sample);
  Lw=np.array(Lw).transpose();

  X0=np.zeros([Se.shape[1]]);
  #X0=Lw;
  Le = Calc_fe(windowed_sample.transpose(),X0)


  c2=(X_Max*np.ones([1,(nabla[1,:].size)])-np.matmul(np.matmul(np.matmul(Le,Tr),np.linalg.inv(S)),nabla));
  
  Le2=Le;
  
  #Can be removed: Linear Solution
  Lul=solvers.qp(matrix(Tr2),-0.5*matrix(np.matmul(Le,Tr).transpose()),matrix(c1.transpose()),matrix(c2.transpose()))
  Lu=Lul;
  #Lul=solvers.qp(matrix(0.5*Tr),-0.5*matrix(np.matmul(Le,Tr).transpose()));#,matrix(c1.transpose()),matrix(c2.transpose()))
  
  
  #Solve nonlinear problem
  e=1e5;
  #while False: #e>1:
  e2=1e6;
  while e<e2 and e>2:
  #while False:
      Le2=Le;
      c2=(X_Max*np.ones([1,(nabla[1,:].size)])-np.matmul(np.matmul(np.matmul(Le2,Tr),np.linalg.inv(S)),nabla));
      Lu=solvers.qp(matrix(Tr2),-0.5*matrix(np.matmul(Le2,Tr).transpose()))#,matrix(c1.transpose()),matrix(c2.transpose()))
      V=np.matmul((Le2-np.array(Lu['x']).transpose()),Tr);
      X1=np.matmul(V,np.linalg.inv(S)).transpose()[:,0];
      X0=0.5*X0+0.5*X1;
      Le = Calc_fe(windowed_sample.transpose(),X0);
      e2=e;
      e=np.mean(np.abs(Le-Le2));
      print(e)
  l1=9;
  #Vl=np.matmul((Le2-np.array(Lul['x']).transpose()),Tr);
  #print(e)
  Vl=np.matmul((Le2-np.array(Lu['x']).transpose()),Tr);
  force=np.array(np.matmul(Se,Lu['x']))-10*15000*(np.matmul(Se,Vl.transpose())-buf_l["speed"][49]);
  #force=50*15000*(np.matmul(Se2,Vl.transpose())-buf_l["speed"]);
  start=int(ts.size/2-l1/2);
  #start=0;
  answer={"force":force[start:start+l1].flatten(),
          "valve":np.zeros([Se.shape[0],1])[start:start+l1].flatten(),
          #"wave":np.matmul(Se,np.matmul(Vl,np.linalg.inv(S)).transpose())[start:start+l1].tolist(),
          "time":ts[start:start+l1].flatten(),
          #"speed":np.matmul(Se,Vl.transpose())[start:start+l1].tolist(),
          #"test":(np.matmul(Se,Le))[start:start+l1].flatten()
          "test":(np.matmul(Se,Vl.transpose()))[start:start+l1].flatten()
          }
  #print(answer)
  conn_model.set_control(answer["time"],answer["force"],answer["valve"],answer["test"])
  

  #Show results;
#  pyplt.figure()
  #pyplt.plot(window_time,windowed_sample.transpose())
  #pyplt.plot(window_time,np.matmul(Se,Lul['x']))
  #pyplt.plot(window_time,1e6*np.matmul(Se,np.matmul(Vl,np.linalg.inv(S)).transpose()))
  #pyplt.legend(["wave excitation","control","position*1e6"])
conn_model.close();
