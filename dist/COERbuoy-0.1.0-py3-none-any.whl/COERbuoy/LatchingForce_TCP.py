#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug  7 23:16:53 2020
Moment-based control with TCP interface; no bugfixing, testing only

@author: Simon
"""
import numpy as np;
import pandas;
from scipy.interpolate import interp1d;
from cvxopt import matrix, solvers;
import matplotlib.pyplot as pyplt;
import socket;
import json;
import sys;
import Floater as fl;
import connection;

#set time step

#set frequencies
omega0=np.array([0.2,0.4,0.6,0.8,1,1.2,1.4,1.6,1.8,2,2.2,2.4,2.6,2.8,3]);

#number of frequencies (k)
k=omega0.size;
host=True;

# Model

rho=1000;
pi=np.pi;
g=9.81;
h=60;

filename="floater.txt";
xi=np.array([0.1,0.4,0.8,1.2,1.4]);
buoy=fl.Floater(xi,9.81,300,0,filename);

with open(filename) as file:
    data=json.load(file);
    #used static damping
    c_minus =data.get("negative_spring",100000);
    d =data.get("damping",100000);
    #Drag coefficent
    cD=data.get("drag",0.5);
    #Percentage mass floater
    m_mass=data.get("mass_percent_floater",0.25)+data.get("mass_percent_slider",0.25)
    added_m=data.get("added_mass",0.95e5);
    #generator efficency
    losses_coil=1/data.get("eff_generator",0.8);
    fr_s=data.get("friction_static",0);
    #static friction
    fk=buoy.Calculate(0,0,0,np.array([]),np.array([]),1,1,np.array([]))
    fk=fk[0]+np.sum(fk[1]);
    latch_eps=data.get("unlatching_treshold",80000);#fk*3*9.81);
    #machinery damping
            

conn_model=connection.connection();
    
if host:
    conn_model.openH();
else:
    conn_model.openC();

latch=False;
while True:
  state=conn_model.get_control();

  print(state["force"][49])
  
  valve=np.ones(9);
  if not latch:
      if state["speed"][49]/(state["speed"][49-1]+0.0001)<0:
          print(str(state["time"][49])+": "+str("latch"))
          latch=True;
  else :
      if np.abs(state["force"][49])>latch_eps:
          print(str(state["time"][49])+": "+str("unlatch"))
          latch=False;
  damping=d*5;
  if not latch:
      damping=d;
      valve=valve*0;
  
  answer={"force":np.ones(9)*state["speed"][49]*damping,
          "valve":valve*0,
          "test":valve*0,
          #"wave":np.matmul(Se,np.matmul(Vl,np.linalg.inv(S)).transpose())[start:start+l1].tolist(),
          "time":np.linspace(-1,1,9),
          #"speed":np.matmul(Se,Vl.transpose())[start:start+l1].tolist(),
          #"test":(np.matmul(Se,Le))[start:start+l1].flatten()
          #"test":(np.matmul(Se,Vl.transpose()))[start:start+l1].flatten()
          }
  #print(answer)
  conn_model.set_control(answer["time"],answer["force"],answer["valve"],answer["test"])
  

conn_model.close();
